package com.example.simplecalc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
